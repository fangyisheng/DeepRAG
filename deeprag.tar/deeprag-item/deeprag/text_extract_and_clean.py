

async def process_text(file_path):
    # 将文本按行分割
    with open(file_path,'r') as file:
        content = file.read()
    lines = content.splitlines()
    # 过滤掉空行，并将非空行合并为一个连续的字符串
    continuous_text = "".join(line.strip().replace(" ", "") for line in lines if line.strip())
    return continuous_text

# test code
# import asyncio
# print(asyncio.run(process_text("test.txt")))