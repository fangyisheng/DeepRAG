a = min(30,1200000/163840)
print(a)